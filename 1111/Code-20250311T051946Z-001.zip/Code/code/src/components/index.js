export { default as Navbar } from "./Navbar";
export { default as Cryptocurrencies } from "./Cryptocurrencies.jsx";
export { default as CryptoDetails } from "./CryptoDetails.jsx";

export { default as Home } from "./Home.jsx";
